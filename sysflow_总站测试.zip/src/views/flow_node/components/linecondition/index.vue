<template>
  <el-dialog
    v-if="dialogline_flag"
    :visible.sync="dialogline_flag"
    center
    width="70%"
    @opened="opened"
    @closed="closed"
  >
    <div slot="title" class="dialog-title">
      <i class="el-icon-edit-outline" />
      <span class="title-text">编辑分支条件</span>
      <div class="button-right">
        <span class="title-close" @click="dialogcancel" />
      </div>
    </div>

    <!-- 表格 -->
    <el-table
      ref="tableData"
      :data="tableData"
      style="width: 100%; margin-top: 20px"
      :highlight-current-row="true"
      :fit="true"
      :header-cell-style="{ 'text-align': 'center', background: '#eef1f6' }"
      tooltip-effect="dark"
      @selection-change="selectRow"
    >
      <el-table-column label="序号" type="index" width="60" align="center" />
      <el-table-column prop="column_name" label="字段名" min-width="60%" align="center">
        <template slot-scope="{ row }">
          <el-select
            v-model="row.column_name"
            placeholder="请选择"
            :loading="loading"
            filterable
            value-key="name"
            @change="selectchange(row)"
            @focus="focus(row)"
          >
            <el-option
              v-for="item in tablecolumn"
              :key="item.name"
              :label="item.name"
              :value="item"
              :disabled="item.disabled"
            />
          </el-select>
        </template>
      </el-table-column>
      <el-table-column prop="verify" label="条件" min-width="60%" align="center">
        <template slot-scope="{ row }">
          <el-select v-model="row.verify" placeholder="请选择">
            <el-option
              v-for="item in verify"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </template>
      </el-table-column>
      <el-table-column prop="expression" label="表达式" min-width="150%" align="center">
        <template slot-scope="{ row }">
          <el-input v-model="row.expression" placeholder="请输入内容" />
        </template>
      </el-table-column>

      <el-table-column width="100" align="center">
        <template slot="header">
          <el-button size="small" type="warning" plain @click="addRow()">
            新 增
          </el-button>
        </template>
        <template slot-scope="scope">
          <el-button
            type="danger"
            size="small"
            plain
            @click.native.prevent="deleteRow(scope.$index, tableData)"
          >
            移 除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <div slot="footer" class="dialog-footer">
      <el-button type="primary" @click="submit">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import {
  get_tablecolumn,
  insert_linesqlwhere,
  get_linesqlwhere
} from '@/api/flowhandle'

export default {
  components: {},
  //   props: {
  //   lineinfo: {
  //     type: Array,
  //     //    default: function () {
  //     //     return []
  //     // }
  //     // default: () => ({}) object
  //     default: () => []
  //   }
  // },
  data() {
    return {
      dialogline_flag: false, // 窗口显示隐藏
      lineinfo: [], // 父组件传值 线数据
      loading: true,
      tablecolumn: [],
      tableDisable: [], // 数据禁用选项
      tableData: [],
      trigger: false,
      previous: [],
      verify: [
        {
          value: '==',
          label: '等于'
        },
        {
          value: '>',
          label: '大于'
        },
        {
          value: '<',
          label: '小于'
        },
        {
          value: '>=',
          label: '大于等于'
        },
        {
          value: '<=',
          label: '小于等于'
        },
        {
          value: '!=',
          label: '不等于'
        },

        {
          value: 'in',
          label: '包含'
        },
        {
          value: 'line',
          label: '模糊'
        }
      ] // 线上的条件
    }
  },
  beforeMount() {},
  mounted() {},
  methods: {
    // 关闭窗口
    dialogcancel() {
      this.dialogline_flag = false
    },
    // 添加行
    addRow() {
      // console.log(this.tableData[this.tableData.length - 1].column_name);
      if (this.tableData.length === 0) {
        const list = {
          fk_line: parseInt(this.lineinfo.id),
          fk_flow: this.lineinfo.fk_flow,
          column_name: '',
          column_type: '',
          verifyvalue: '',
          verify: '',
          expression: ''
        }
        this.tableData.push(list)
      } else {
        if (this.tableData[this.tableData.length - 1].column_name === '') {
          this.$message.warning('请先完善信息!')
          return
        } else {
          const list = {
            fk_line: parseInt(this.lineinfo.id),
            fk_flow: this.lineinfo.fk_flow,
            column_name: '',
            column_type: '',
            verifyvalue: '',
            verify: '',
            expression: ''
          }
          this.tableData.push(list)
        }
      }
    },
    // 移除行
    deleteRow(index, rows) {
      this.$confirm('确定移除该条信息?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
        .then(() => {
          if (rows[index].column_name === '') {
            rows.splice(index, 1)
            this.$message({
              type: 'success',
              message: '移除成功!'
            })
          } else {
            for (const i in this.tableDisable) {
              if (this.tableDisable[i].name === rows[index].column_name.name) {
                this.tableDisable.splice(i, 1)
              }
            }
            // 如果没有需要屏蔽的选项，则将所有选项设置为启用
            if (!this.tableDisable || this.tableDisable.length < 1) {
              for (const option of this.tablecolumn) {
                this.$set(option, 'disabled', false)
              }
            } else {
              // 按需屏蔽选项
              for (const option of this.tablecolumn) {
                const found = this.tableDisable.find(item => item === option)
                if (found) {
                  this.$set(option, 'disabled', true)
                } else {
                  this.$set(option, 'disabled', false)
                }
              }
            }
            rows.splice(index, 1)
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            if (this.tableData.length === 0) {
              location.reload()
            }
          }
          // }
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
    },
    // 提交
    submit() {
      for (const key in this.tableData) {
        if (
          this.tableData[key].column_name.name === '' ||
          this.tableData[key].verify === '' ||
          this.tableData[key].expression === ''
        ) {
          this.warning_box('请将信息填写完整')
          return
        }
        // 循环读取列类型 赋值给tabledata
        const columntype = this.tablecolumn.find(item => {
          if (this.tableData[key].column_name.name === undefined) {
            return item.name === this.tableData[key].column_name
          } else {
            return item.name === this.tableData[key].column_name.name
          }
        })
        this.tableData[key].column_name = columntype.name
        this.tableData[key].column_type = columntype.type
        // 循环读取条件 赋值给verifyvalue
        const verifyvalue = this.verify.find(item => {
          return item.value === this.tableData[key].verify
        })
        this.tableData[key].verifyvalue = verifyvalue.label
      }
      if (this.tableData.length === 0) {
        this.warning_box('请添加内容')
        return
      }
      /*
      如果在这不判断的话 后端不会执行成功 zj 20210915
      for (const key in this.tableData) {
        if (this.tableData[key].column_type === 'int') {
              console.log('expression可被转换')
        }
      }
      */
      // 插入数据
      insert_linesqlwhere(this.tableData).then(res => {
        if (res.code === 100) {
          this.insert_box(res.code)
          this.dialogline_flag = false
        } else if (res.code === 101) {
          this.insert_box(res.code, res.msg)
          return
        } else if (res.code === 102) {
          this.insert_box(res.code, res.msg)
          return
        } else if (res.code === -1) {
          this.insert_box(res.code, res.msg)
          return
        }
      })
    },
    // 加载数据表的列
    get_tablecolumn() {
      this.loading = true
      get_tablecolumn({ fk_flow: this.lineinfo.fk_flow }).then(res => {
        if (res.code === 100) {
          this.tablecolumn = res.data
          // 将列表里已有的选项禁用
          if (this.tableData.length > 0) {
            for (const i in this.tablecolumn) {
              for (const j in this.tableData) {
                if (
                  this.tablecolumn[i].name === this.tableData[j].column_name
                ) {
                  this.tablecolumn[i].disabled = true
                  this.tableDisable.push(this.tablecolumn[i])
                }
              }
            }
          }
        }
      })
      this.loading = false
    },

    // 窗口被打开
    opened() {
      get_linesqlwhere({
        fk_flow: this.lineinfo.fk_flow,
        fk_line: this.lineinfo.id
      }).then(res => {
        if (res.code === 100) {
          this.tableData = res.data
          this.get_tablecolumn()
        }
      })
    },
    // 窗口关闭
    closed() {
      this.tableData = []
    },
    // 选中事件
    selectRow() {},
    // 下拉获取焦点事件
    focus(row) {
      if (row.column_name === '') {
        this.trigger = true
      } else {
        this.trigger = false
        if (row.column_name.name === undefined) {
          this.previous = [
            {
              name: row.column_name,
              type: row.column_type,
              disabled: true
            }
          ]
        } else {
          this.previous = [
            {
              name: row.column_name.name,
              type: row.column_name.type,
              disabled: true
            }
          ]
        }
      }
    },
    // 下拉列表选择
    selectchange(val) {
      if (!val) {
        return
      }
      if (this.trigger === true) {
        if (val.column_name.name === undefined) {
          this.tableDisable.push(val)
        } else {
          this.tableDisable.push(val.column_name)
        }
        // 获取需要屏蔽的选项
        const needDisabledOptions = this.tableDisable
        // 按需屏蔽选项
        for (const option of this.tablecolumn) {
          const result = needDisabledOptions.find(item => item === option)
          if (result) {
            this.$set(option, 'disabled', true)
          } else {
            this.$set(option, 'disabled', false)
          }
        }
      } else {
        // console.log("选择过");
        const that = this
        for (const i in this.tablecolumn) {
          for (const j in this.previous) {
            if (this.tablecolumn[i].name === this.previous[j].name) {
              that.tablecolumn[i] = {
                name: that.tablecolumn[i].name,
                type: that.tablecolumn[i].type,
                disabled: false
              }
            }
          }
        }
        for (const i in this.tableDisable) {
          for (const j in this.previous) {
            if (this.tableDisable[i].name === this.previous[j].name) {
              this.tableDisable.splice(i, this.tableDisable.length - 1)
            }
          }
        }
        if (val.column_name.name === undefined) {
          this.tableDisable.push(val)
        } else {
          this.tableDisable.push(val.column_name)
        }
        // 获取需要屏蔽的选项
        const needDisabledOptions = this.tableDisable
        // 按需屏蔽选项
        for (const option of this.tablecolumn) {
          const result = needDisabledOptions.find(item => item === option)
          if (result) {
            this.$set(option, 'disabled', true)
          } else {
            this.$set(option, 'disabled', false)
          }
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.dialog-title {
  text-align: center;
  font-size: 16px;
  font-weight: 700;
  overflow: hidden;
}
.dialog-title i {
  color: #45a4f9;
  /* color: #0B2278; */
  font-size: 16px;
  line-height: 38px;
}
.dialog-footer {
  text-align: center;
  font-size: 16px;
  font-weight: 700;
}
</style>

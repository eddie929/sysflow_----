<template>
  <el-dialog
    title="提示"
    :visible.sync="dialogVisible"
    width="30%"
  />
</template>

<script>
export default {
data() {
    return {
        dialogVisible: false
    }
}
}
</script>

<style>

</style>

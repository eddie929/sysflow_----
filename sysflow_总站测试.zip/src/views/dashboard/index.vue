<template>
  <div>
    <initiateflow ref="initiateflow" />
  </div>
</template>

<script>
import initiateflow from '../initiateflow/index1.vue' // 查看所有流程

export default {
  components: { initiateflow },
  methods: {}
}
</script>

<style></style>

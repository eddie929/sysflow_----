module.exports = {
  env: {
    jest: true
  }
}
